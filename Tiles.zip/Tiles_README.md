
# Tiles.py

### Overview
`Tiles.py` is a Python script that implements multiple search algorithms to solve the classic 8-puzzle problem. The program provides an interactive way for users to input an initial 8-puzzle configuration and solve it using various search techniques like **Breadth-First Search (BFS)**, **Iterative Deepening Depth-First Search (IDDFS)**, **Greedy Best-First Search (GBFS)**, and **A***.

### Features
- Validates if the given 8-puzzle configuration is solvable.
- Provides user input functionality for initial puzzle configuration.
- Implements and compares the following search algorithms:
  - **Breadth-First Search (BFS)**
  - **Iterative Deepening Depth-First Search (IDDFS)**
  - **Greedy Best-First Search (GBFS)** using Misplaced Tiles heuristic.
  - **A*** using Misplaced Tiles heuristic.
- Displays the solution path, number of nodes expanded, nodes created, and the execution time for each algorithm.

---

### Installation and Usage
#### Prerequisites
- Python 3.6 or later.

#### Running the Program
1. Clone or download the script.
2. Run the script:
   ```bash
   python Tiles.py
   ```
3. Enter the puzzle configuration when prompted. Provide 9 unique integers from 0-8, where `0` represents the empty space.

#### Example Input:
```plaintext
Enter the numbers in the puzzle (0-8) separated by spaces: 1 2 3 4 0 5 6 7 8
```

#### Example Output:
```plaintext
Solving the 8-puzzle using BFS:
Solution path: 4 -> 5 -> ...
Number of nodes expanded: 15
Number of nodes created: 20
Time taken BFS: 0.0034 seconds
```

---

### Algorithms
#### 1. Breadth-First Search (BFS)
- Explores all nodes at the current depth level before moving to the next level.
- Guarantees the shortest solution path but may consume significant memory.

#### 2. Iterative Deepening Depth-First Search (IDDFS)
- Combines the space efficiency of DFS with the completeness of BFS.
- Iteratively increases the depth limit until the goal is found.

#### 3. Greedy Best-First Search (GBFS)
- Uses the **Misplaced Tiles Heuristic** to guide the search.
- Prioritizes nodes that appear closer to the goal state but does not guarantee optimal solutions.

#### 4. A* Search
- Combines the path cost (`g(n)`) and the heuristic estimate (`h(n)`) to prioritize nodes.
- Uses the **Misplaced Tiles Heuristic** as `h(n)`.
- Guarantees the shortest solution path if the heuristic is admissible.

---

### Functions
#### Core Classes
- **`Node`**: Represents a state of the puzzle.
- **`Problem`**: Encapsulates the problem definition (initial and goal states, actions, etc.).

#### Utility Functions
- **`is_solvable(state)`**: Checks if the given puzzle configuration is solvable.
- **`expand(problem, node)`**: Generates child nodes for a given node.
- **`print_path(node)`**: Prints the solution path from the root to the goal node.
- **`get_solution_path(node)`**: Returns a formatted string of the solution path.

#### Search Algorithms
- **`bfs(problem)`**: Implements Breadth-First Search.
- **`ids(problem)`**: Implements Iterative Deepening Depth-First Search.
- **`gbfs(problem)`**: Implements Greedy Best-First Search using Misplaced Tiles heuristic.
- **`a_star(problem)`**: Implements A* Search using Misplaced Tiles heuristic.

---


